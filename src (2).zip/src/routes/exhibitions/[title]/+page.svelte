<script>
	import FaunaPage from "$lib/exhbitions/fauna/FaunaPage.svelte";
</script>

<div>
	<FaunaPage/>
</div>