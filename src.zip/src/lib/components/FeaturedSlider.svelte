<script>
	import { addItem } from '$lib/stores/cartStore';
	import { toggleCartSlider, isCartSliderOpen } from '$lib/stores/cartSliderStore';
	import { goto } from '$app/navigation';

	export let products;

	// Limit to 20 newest products
	let limitedProducts = products
		.slice()
		.sort((a, b) => new Date(b.date_modified) - new Date(a.date_modified))
		.slice(0, 20);

	let slider;
	let isCartOpen = false;
	let scrollTarget = 0;
	let currentScroll = 0;
	let isAnimating = false;

	// Subscribe to the cart slider state
	$: isCartSliderOpen.subscribe((value) => {
		isCartOpen = value;
	});

	function handleProductClick(productId) {
		goto(`/shop/${productId}`);
	}

	function handleMouseMove(event) {
		if (window.innerWidth >= 768) {
			const rect = slider.getBoundingClientRect();
			const mouseX = event.clientX - rect.left;
			const sliderWidth = rect.width;
			const middleX = sliderWidth / 2;
			const offsetX = mouseX - middleX;
			const maxScroll = slider.scrollWidth - sliderWidth;

			// Constrain scrollTarget within the slider bounds
			scrollTarget = Math.min(maxScroll, Math.max(0, currentScroll + (offsetX / middleX) * maxScroll / 2));

			if (!isAnimating) {
				isAnimating = true;
				animateScroll();
			}
		}
	}

	function animateScroll() {
		const easing = 0.1;
		const distance = scrollTarget - currentScroll;
		currentScroll += distance * easing;
		slider.scrollLeft = currentScroll;

		// Stop animating if the slider reaches the start or end
		if (Math.abs(distance) > 0.5 && currentScroll !== 0 && currentScroll !== slider.scrollWidth - slider.clientWidth) {
			requestAnimationFrame(animateScroll);
		} else {
			isAnimating = false;
		}
	}
</script>

<div class="featured-slider-container" bind:this={slider} on:mousemove={handleMouseMove}>
	<div class="featured-slider flex gap-md">
		{#each limitedProducts as product}
			<div class="featured-card" on:click={() => handleProductClick(product.id)}>
				<!-- Display Product Tags Above the Image -->
				<div class="tag-container">
					{#each product.tags as tag}
						<span class="tag">{tag.name}</span>
					{/each}
				</div>
				<!-- Product Image -->
				<img src={product.images[0]?.src} alt={product.name} class="product-image" />
			</div>
		{/each}
	</div>
</div>

<style>
.featured-slider-container {
	width: 100%;
	overflow: hidden;
	transition: all 0.3s ease;
}

@media (max-width: 767px) {
	.featured-slider-container {
		overflow-x: auto;
		scroll-snap-type: x mandatory;
		-webkit-overflow-scrolling: touch;
	}

	.featured-slider {
		display: flex;
		gap: 1rem;
	}

	.featured-card {
		flex: 0 0 50%;
		scroll-snap-align: start;
		position: relative;
	}
}

@media (min-width: 768px) {
	.featured-slider {
		display: flex;
		gap: 1rem;
	}

	.featured-card {
		flex: 0 0 300px;
		height: 50vh;
		position: relative;
		overflow: hidden;
		transition: flex 0.9s ease;
		cursor: pointer;
	}

	.featured-card:hover {
		flex: 0 0 600px;
	}
}

.product-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.tag-container {
	position: absolute;
	top: 8px;
	left: 8px;
	display: flex;
	gap: 0.25rem;
	flex-wrap: wrap;
	z-index: 10;
}

.tag {
	background-color: var(--primary-color);
	color: var(--background-color);
	padding: 0.25rem 0.5rem;
	border-radius: 9999px;
	font-size: 0.75rem;
	font-weight: 600;
}

</style>
