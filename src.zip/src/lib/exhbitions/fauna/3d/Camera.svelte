<script>
    import * as THREE from 'three';
    export let position = [0, 2, 5];
    export let scene;
    export let renderer;

    let camera;

    $: if (scene && renderer) {
        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(...position);
        scene.add(camera);
        renderer.camera = camera;
    }
</script>
