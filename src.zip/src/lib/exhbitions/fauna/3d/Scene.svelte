<script>
    import * as THREE from 'three';
    import { onMount } from 'svelte';
    import { createEventDispatcher } from 'svelte';

    let canvas;
    let renderer, scene;
    const dispatch = createEventDispatcher();

    onMount(() => {
        renderer = new THREE.WebGLRenderer({ canvas });
        renderer.setSize(window.innerWidth, window.innerHeight);

        scene = new THREE.Scene();
        scene.background = new THREE.Color(0x20232a);

        // Dispatch the scene and renderer to child components
        dispatch('sceneReady', { scene, renderer });

        function animate() {
            requestAnimationFrame(animate);
            renderer.render(scene, renderer.camera);
        }
        animate();

        return () => renderer.dispose();
    });
</script>

<canvas bind:this={canvas}></canvas>

<style>
    canvas {
        width: 100vw;
        height: 100vh;
        display: block;
    }
</style>

<slot />
